'use strict';
const mysql = require('mysql');
//local mysql db connection
const dbConn = mysql.createConnection({
  host     : 'ec2-54-88-18-43.compute-1.amazonaws.com',
  user     : 'shunt2',
  password : 'stormsoldier!468',
  database : 'shunt'
});
dbConn.connect(function(err) {
  if (err) throw err;
  console.log("Database Connected!");
});
module.exports = dbConn;